#!/usr/bin/env python3
"""Cowork ROI — TF-IDF session classifier v6.

Drop-in replacement for the hand-crafted keyword-lexicon classifier.

BUSINESS-PROCESS LABELS are assigned via TF-IDF cosine similarity against the
APQC Process Classification Framework (PCF) — a vendor-neutral, publicly
maintained business-process taxonomy (~13 top-level categories, ~1 000 sub-
processes). This replaces substring matching against a hand-tuned PROCESS_LEXICON
that suffered from exact-match brittleness (plural/synonym misses, vendor-name
bleed-through, missing abbreviations, English-only vocabulary).

Architecture
------------
  goal text
      │
      ▼
  tokenize()          ← digit-letter boundaries split, lowercase, min-length filter
      │
      ▼
  embed()             ← TF-IDF sparse vector  [SWAP HERE for dense embeddings]
      │
      ▼
  nearest()           ← cosine similarity vs. APQC taxonomy vectors
      │
      ▼
  APQC category label

Upgrading to dense semantic embeddings (Azure OpenAI text-embedding-3-small)
-----------------------------------------------------------------------------
Replace the body of embed() with:

    import requests
    resp = requests.post(
        "https://<your-resource>.openai.azure.com/openai/deployments/"
        "text-embedding-3-small/embeddings?api-version=2024-02-01",
        headers={"api-key": "<key>"},
        json={"input": text},
        timeout=10,
    )
    return resp.json()["data"][0]["embedding"]   # list[float]

Then change cosine() to operate on list[float] instead of dict. Everything
else — build_index(), nearest(), the session loop — stays identical.

Connecting to O*NET Web Services (free, no auth required)
----------------------------------------------------------
O*NET Detailed Work Activities (DWAs) are an occupation-centric alternative
taxonomy. To use them, replace PROCESS_TAXONOMY entries with O*NET DWA
categories fetched at startup:

    import requests
    dwa = requests.get("https://services.onetcenter.org/ws/dwa_categories",
                       headers={"Accept": "application/json"}).json()
    entries = [{"id": d["code"], "label": d["title"],
                "description": d["description"]} for d in dwa["dwa_category"]]

Same embed() + nearest() call applies; only the taxonomy source changes.
O*NET is better for occupation-level granularity; APQC PCF is better for
pure business-process labeling across roles.

Run-local labels
----------------
Use process/value_pillar/job/jtbd supplied in this run's harvested records, with the
bundled process taxonomy as the fallback. No prior-task naming memory is loaded or
saved. An optional --overrides file can be supplied explicitly for manual use; the
normal skill workflow does not use it, and there is no automatic override-file lookup.

Usage: python classify.py --in working/cowork_raw.json --out working/cowork_sessions.json
"""
import json, argparse, collections, re, math, copy
from report_taxonomies import PROCESS_TAXONOMY, ROLE_TAXONOMY

# ---------------------------------------------------------------------------
# Tokenizer — splits on non-alphanumeric AND on digit↔letter transitions
# so "fy26" → ["fy", "26"], "q4" → ["q", "4"], "api" → ["api"].
# This is the main reason the old lexicon missed "FY26" vs "fy" patterns.
# ---------------------------------------------------------------------------

def tokenize(text: str) -> list:
    t = (text or "").lower()
    t = re.sub(r"([a-z])([0-9])", r"\1 \2", t)  # fy26  → fy 26
    t = re.sub(r"([0-9])([a-z])", r"\1 \2", t)  # 3way  → 3 way
    return [tok for tok in re.split(r"[^a-z0-9]+", t) if len(tok) > 1]


# ---------------------------------------------------------------------------
# TF-IDF "embedding" — pure Python, zero external deps.
# ---------------------------------------------------------------------------

def build_index(entries: list) -> tuple:
    """Pre-compute TF-IDF vectors for every taxonomy entry.

    Returns (vectors, idf) where:
        vectors: list of (label, {token: weight})
        idf:     dict {token: idf_value}  — shared vocabulary
    """
    N = len(entries)
    df: dict = collections.defaultdict(int)
    tok_lists = []
    for e in entries:
        toks = tokenize(e["label"] + " " + e["description"])
        tok_lists.append(toks)
        for t in set(toks):
            df[t] += 1

    # Smoothed IDF: log((N+1)/(df+1)) + 1  — avoids zero for unseen terms
    idf = {t: math.log((N + 1.0) / (c + 1.0)) + 1.0 for t, c in df.items()}

    vectors = []
    for i, e in enumerate(entries):
        tf = collections.Counter(tok_lists[i])
        total = len(tok_lists[i]) or 1
        vec = {t: (cnt / total) * idf[t] for t, cnt in tf.items()}
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        vectors.append((e["label"], {t: v / norm for t, v in vec.items()}))

    return vectors, idf


def embed(text: str, idf: dict) -> dict:
    """Sparse TF-IDF vector for a query string.

    SWAP THIS FUNCTION to use dense semantic embeddings — see module docstring.
    The signature and return type (dict) can change to list[float] if you also
    update cosine() accordingly; nothing else needs to change.
    """
    toks = tokenize(text)
    tf = collections.Counter(toks)
    total = len(toks) or 1
    # Unknown tokens (not in training corpus) get idf = 1.0 as a neutral weight
    vec = {t: (cnt / total) * idf.get(t, 1.0) for t, cnt in tf.items()}
    norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
    return {t: v / norm for t, v in vec.items()}


def cosine(a: dict, b: dict) -> float:
    """Dot product of two normalized sparse vectors = cosine similarity."""
    return sum(a.get(t, 0.0) * w for t, w in b.items())


def nearest(goal: str, cat_hint: str, vectors: list, idf: dict) -> str:
    """Return the best-matching APQC label.

    cat_hint: primary methodology category (analysis/document/code/…) used as
    a lightweight tiebreaker — it narrows ambiguous goals (e.g. 'document'
    boosts 'Sales & Customer Engagement' slightly over 'Analytics & Reporting'
    for a deck-centric goal).
    """
    # Combine goal text with a single hint token so category vocabulary can tip ties
    query = embed(goal + " " + cat_hint, idf)
    scored = sorted(
        ((label, cosine(query, vec)) for label, vec in vectors),
        key=lambda x: x[1],
        reverse=True,
    )
    return scored[0][0]  # always return best match; score is available if needed


# ---------------------------------------------------------------------------
# Taxonomy loader + optional override file
# ---------------------------------------------------------------------------

_PILLAR_CSS = {"Revenue Growth": "rev", "Cost Reduction": "cost",
               "Risk Mitigation": "risk", "Transformation": "trans"}


def load_taxonomy() -> tuple:
    entries = PROCESS_TAXONOMY
    pillar_lookup = {
        e["label"]: (e.get("value_pillar", "Transformation"),
                     e.get("pillar_css", "perf"))
        for e in entries
    }
    job_lookup = {
        e["label"]: (e.get("job", "Other"), e.get("jtbd", ""))
        for e in entries
    }
    # Returns ((vectors, idf), pillar_lookup, job_lookup)
    return build_index(entries), pillar_lookup, job_lookup


def load_overrides(path: str | None = None) -> dict:
    """Read only an explicitly requested manual override file."""
    if path is None:
        return {}
    with open(path, encoding="utf-8-sig") as f:
        overrides = json.load(f)
    if not isinstance(overrides, dict):
        raise ValueError("Explicit overrides must be an object keyed by session ID")
    return overrides


# ---------------------------------------------------------------------------
# Methodology category logic — unchanged from v5.
# This answers HOW the work was done (analysis / code / document / …).
# The APQC lookup above answers WHAT business process it served.
# ---------------------------------------------------------------------------

EXT2CAT = {
    # Document & content creation
    "docx": "document", "doc": "document", "pdf": "document",
    "md": "document", "txt": "document", "rtf": "document",
    "pptx": "document", "ppt": "document",
    "png": "document", "jpg": "document", "jpeg": "document",
    "svg": "document", "eps": "document", "gif": "document",
    # Spreadsheets are CREATED content/data documents ("creating visuals, organizing
    # files") per the taxonomy table -> document. Analysis is assigned from goal text
    # ("synthesizing findings, comparing options, briefings"), never from a file type.
    "xlsx": "document", "xlsm": "document", "xls": "document",
    "csv": "document", "tsv": "document",
    # Write or debug code
    "html": "code", "htm": "code", "py": "code", "ps1": "code",
    "js": "code", "ts": "code", "sql": "code", "ipynb": "code",
    "sh": "code", "yaml": "code", "yml": "code",
    # Specialized workflows
    "zip": "special", "skill": "special",
}

PRIORITY = ["code", "analysis", "special", "document", "comms", "meeting", "email", "general"]

# ---------------------------------------------------------------------------
# Goal-text signal vocabulary — enriched from the Cowork usage taxonomy table
# (Description/Examples column). Each set below deliberately mirrors one row of
# that table so goal phrasing alone can place a session even when no telltale
# file extension was saved. Categories are UNCHANGED (still the 8 methodology
# keys); only the descriptive vocabulary that routes into them is tightened.
# ---------------------------------------------------------------------------

# Analysis & Research — searching org data, synthesizing findings, comparing
# options, explaining concepts, preparing briefings from multiple sources.
ANALYSIS_SIGNALS = (
    "analyz", "analyse", "analysis", "research", "synthes", "investigat",
    "benchmark", "compar", "evaluat", "assess", "audit", "deep dive", "diagnos",
    "forecast", "roi analysis", "roi report", "business case", "cost analysis", "quantif", "calculat",
    "insight", "trend",
    # taxonomy-derived additions:
    "briefing", "brief on", "search", "org data", "explain", "explaining",
    "concept", "option", "findings", "multiple source", "compile", "summariz",
)
REVIEW_VERBS = ("review", "read", "examine", "look at", "go through", "study")
SOURCE_PREPS = ("from", "based on", "using", "out of", "off of", "against")
ANALYTICAL_OBJECTS = (
    "report", "data", "dataset", "findings", "result", "dashboard", "metric",
    "number", "log", "telemetry", "usage", "spreadsheet", "chart", "figure", "source",
)
# Write or debug code — writing/debugging code, code review, script generation, code analysis.
CODE_SIGNALS = (
    "debug", "refactor", " script", "parser", " api", " app ", "application",
    "pipeline", "deploy", "integrat", "function", " bug ", "codebase",
    # taxonomy-derived additions:
    "code review", "script generation", "write code", "writing code",
    "code analysis", "coding",
)
# Email workflows — drafting/replying to emails, summarizing threads, triaging
# inbox, managing mail (Outlook-centered).
EMAIL_SIGNALS = (
    "email", "inbox", "reply to", "e-mail", "outlook",
    "draft email", "drafting email", "summarize thread", "mail rule",
    "triage inbox", "triage email",
)
# Communication workflows — the SAME ideas as Email, but centered on Microsoft
# Teams: synthesizing, posting, triaging and managing across Teams messages and
# channels (chats, channel posts, replies, announcements, mentions).
COMMS_SIGNALS = (
    "teams message", "teams chat", "teams channel", "chat message",
    "post to teams", "post to the channel", "post in teams", "channel message",
    "reply in teams", "teams thread", "summarize the channel", "summarize teams",
    "triage teams", "manage the channel", "communication rule",
    "notify the team", "announcement", "@mention", "mention me",
)
# Document & content creation — drafting docs/presentations, editing text,
# creating visuals, organizing files in OneDrive/SharePoint.
DOC_SIGNALS = (
    "presentation", "deck", "slide", "one-pager", "write-up", "writeup",
    "draft a doc", "drafting doc", "editing text", "edit text", "visual",
    "onedrive", "sharepoint", "organize file", "content creation", "newsletter",
)
# Specialized workflows — scheduling calendar events, managing task lists,
# multi-step M365 workflows, recurring prompts, and connectors (Dynamics 365,
# ADO Boards, Power BI, Fabric, ServiceNow, Salesforce, SAP).
SPECIAL_SIGNALS = (
    "workflow automation", "automat", "recurring prompt", "scheduled prompt",
    "schedule prompt", "task list", "multi-step", "multistep", "connector",
    "dynamics 365", "ado boards", "power bi", "fabric", "servicenow",
    "salesforce", " sap ", "schedule calendar", "scheduling calendar",
    "calendar event", "package", "bundle", "skill",
)
# Meeting workflows — preparing meeting briefings, recapping transcripts,
# extracting action items, calendar lookups.
MEETING_SIGNALS = (
    "meeting", "transcript", "recap", "standup", "minutes", "agenda",
    "action item", "calendar lookup", "meeting brief",
)
# General assistance & learning — kept as the low-priority fallback
# ("product guidance, discovering capabilities, troubleshooting, learning, Q&A").
DATA_EXT = {"xlsx", "xlsm", "xls", "csv", "tsv", "json", "parquet"}

# Genuine "content" deliverables — the forms that legitimately mean
# "Document & content creation" ONLY when one of them is a PRIMARY OUTPUT:
# a PowerPoint, a Word/PDF document, a Loop/OneNote page, or an image.
# Note: .md/.txt are deliberately EXCLUDED — a Markdown/plain-text file is just
# as often an automation byproduct (execution log, README, notes) as authored
# content, so it must not by itself put a session in the Document category.
# The `document` tag survives only if a session actually PRODUCED one of these.
CONTENT_EXT = {
    "pptx", "ppt",                                   # PowerPoint
    "docx", "doc", "pdf", "rtf", "odt",              # documents
    "loop", "one", "onetoc2",                        # Loop / OneNote
    "png", "jpg", "jpeg", "gif", "svg", "eps",       # images
    "webp", "heic", "bmp", "tif", "tiff",
    "xlsx", "xlsm", "xls", "csv", "tsv",             # spreadsheets = created content
}


def ext_of(name: str) -> str:
    n = str(name)
    return n.split(".")[-1].lower() if "." in n else ""


def norm(items) -> list:
    out = []
    for a in items or []:
        if isinstance(a, dict):
            name = a.get("name", "artifact")
            ext = (a.get("ext") or ext_of(name)).lower()
        else:
            name = str(a)
            ext = ext_of(name)
        if str(name).startswith("(input)"):
            continue
        item = copy.deepcopy(a) if isinstance(a, dict) else {}
        item.update({"name": name, "ext": ext})
        if isinstance(a, dict) and "skills" in a:
            item["skills"] = list(dict.fromkeys(x for x in (a["skills"] or []) if x))
        out.append(item)
    return out


def goal_categories(goal: str) -> list:
    g = " " + (goal or "").lower() + " "
    cats = []
    has_object = any(o in g for o in ANALYTICAL_OBJECTS)
    if (
        any(v in g for v in ANALYSIS_SIGNALS)
        or (has_object and any(v in g for v in REVIEW_VERBS))
        or (has_object and any(p + " " in g for p in SOURCE_PREPS))
    ):
        cats.append("analysis")
    if any(v in g for v in CODE_SIGNALS):
        cats.append("code")
    if any(v in g for v in SPECIAL_SIGNALS):
        cats.append("special")
    if any(v in g for v in DOC_SIGNALS):
        cats.append("document")
    if any(v in g for v in COMMS_SIGNALS):
        cats.append("comms")
    if any(v in g for v in EMAIL_SIGNALS):
        cats.append("email")
    if any(v in g for v in MEETING_SIGNALS):
        cats.append("meeting")
    return cats


def load_roles_taxonomy():
    """16-role keyword taxonomy + default, ported from microsoft/What-I-Did-Copilot."""
    return copy.deepcopy(ROLE_TAXONOMY["roles"]), ROLE_TAXONOMY["default"]


def assign_roles(text: str, taxonomy: list, default: str) -> list:
    """Keyword FALLBACK — the professional roles a billing firm would charge for this work.
    Used only when the harvest LLM did not already tag professional_roles."""
    t = (text or "").lower()
    hits = []
    for entry in taxonomy:
        if entry["role"] not in hits and any(kw.lower() in t for kw in entry.get("keywords", [])):
            hits.append(entry["role"])
    return hits[:2] or [default]


def classify_session(s: dict) -> tuple:
    outputs = norm(s.get("outputs") if s.get("outputs") is not None else s.get("artifacts", []))
    inputs = norm(s.get("inputs", []))
    cats = []
    for a in outputs:
        c = EXT2CAT.get(a["ext"])
        if c and c not in cats:
            cats.append(c)
    for c in goal_categories(s.get("goal", "")):
        if c not in cats:
            cats.append(c)
    # Multi-source synthesis = analysis ("preparing briefings from multiple sources").
    # A single data-file input is NOT analysis on its own.
    if len(inputs) >= 3 and "analysis" not in cats:
        cats.append("analysis")
    # Primary-output gate for Document & content creation: keep `document` ONLY
    # when a genuine content artifact (deck / doc / PDF / Loop / image) was
    # actually PRODUCED. This stops an incidental .md/.txt log — or a chat-only
    # session with no saved deliverable — from landing in the Document bucket.
    if "document" in cats and not any(a["ext"] in CONTENT_EXT for a in outputs):
        cats.remove("document")
    if not cats:
        return (["general"], "conversational (no saved artifact)")
    cats.sort(key=lambda c: PRIORITY.index(c) if c in PRIORITY else 99)
    return (cats[:2], "" if outputs else "conversational (no saved artifact)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(inp: str, out: str, overrides_path: str | None = None) -> None:
    with open(inp, encoding="utf-8-sig") as f:
        d = json.load(f)
    sessions = d.get("sessions", [])

    (vectors, idf), pillar_lookup, job_lookup = load_taxonomy()
    overrides = load_overrides(overrides_path)
    roles_tax, roles_default = load_roles_taxonomy()

    classified = []
    conv = 0
    seen_ids = set()

    for s in sessions:
        sid = s.get("id")
        if (not isinstance(sid, str) or not sid.strip() or sid != sid.strip()
                or any(ord(c) < 32 for c in sid)):
            raise ValueError("Each session requires a non-empty string id without surrounding whitespace or control characters")
        if sid in seen_ids:
            raise ValueError(f"Duplicate session id: {sid!r}")
        seen_ids.add(sid)
        if s.get("runs") is not None:
            if not isinstance(s["runs"], dict):
                raise ValueError(f"Session {sid!r}: runs must be an object of non-negative integer counts")
            for category, count in s["runs"].items():
                if not isinstance(category, str) or not category.strip():
                    raise ValueError(f"Session {sid!r}: run categories must be non-empty strings")
                if isinstance(count, bool) or not isinstance(count, int) or count < 0:
                    raise ValueError(f"Session {sid!r}: run count for {category!r} must be a non-negative integer")
        tasks, note = classify_session(s)
        if note:
            conv += 1
        inputs = norm(s.get("inputs", []))
        outputs = norm(
            s.get("outputs") if s.get("outputs") is not None else s.get("artifacts", [])
        )
        primary = tasks[0] if tasks else "general"

        for field in ("process", "value_pillar", "job", "jtbd"):
            if s.get(field) is not None and not isinstance(s[field], str):
                raise ValueError(f"Session {sid!r}: {field} must be text when supplied")
        # Current-run labels never depend on an earlier task's saved mapping.
        ov = overrides.get(sid)
        if isinstance(ov, dict):
            process = ov.get("process")
        elif isinstance(ov, str):
            process = ov
        else:
            process = None
        process_source = "override"
        if not process and s.get("process"):
            process = s["process"]
            process_source = "supplied"
        if not process:
            process = "General Productivity" if primary == "general" else nearest(s.get("goal", ""), primary, vectors, idf)
            process_source = "fallback" if primary == "general" else "taxonomy"

        # Explicit manual overrides, then current-run fields, then taxonomy defaults.
        t_pillar, t_css = pillar_lookup.get(process, ("Transformation", "trans"))
        t_job, t_jtbd = job_lookup.get(process, ("Other", ""))
        labels = ov if isinstance(ov, dict) else {}
        value_pillar = labels.get("pillar") or s.get("value_pillar") or t_pillar
        job = labels.get("job") or s.get("job") or t_job
        jtbd = (labels["jtbd"] if labels.get("jtbd") is not None else
                s["jtbd"] if s.get("jtbd") is not None else t_jtbd)
        pillar_css = _PILLAR_CSS.get(value_pillar, t_css)
        value_pillar_source = ("override" if labels.get("pillar")
                               else "supplied" if s.get("value_pillar")
                               else "taxonomy" if process in pillar_lookup else "fallback")
        jtbd_source = ("override" if labels.get("jtbd") is not None
                       else "supplied" if s.get("jtbd") is not None
                       else "taxonomy" if process in job_lookup else "fallback")

        rec = copy.deepcopy(s)
        rec.update({
            "id": sid,
            "date": s.get("date", ""),
            "hour": int(s.get("hour", 12)),
            "goal": s.get("goal", "Cowork session"),
            "inputs": inputs,
            "outputs": outputs,
            "tasks": tasks,
            "category_source": "deterministic-artifact-goal-rules",
            "runs_source": s.get("runs_source", "supplied" if s.get("runs") is not None else "classified-category-estimate"),
            "process": process,
            "process_source": process_source,
            "value_pillar": value_pillar,
            "value_pillar_source": value_pillar_source,
            "pillar_css": pillar_css,
            "job": job,
            "jtbd": jtbd,
            "jtbd_source": jtbd_source,
            "source_record": copy.deepcopy(s),
            "skills": [x for x in (s.get("skills") or []) if x],
            "professional_roles": ([x for x in (s.get("professional_roles") or []) if x]
                                   or assign_roles(
                                       " ".join([s.get("goal", "")] + tasks
                                                + [x for x in (s.get("skills") or [])]),
                                       roles_tax, roles_default)),
            "professional_roles_source": s.get("professional_roles_source",
                                              "supplied" if s.get("professional_roles") else "keyword-inferred"),
        })
        if s.get("exec_min") is not None:
            rec["exec_min"] = s["exec_min"]
        if s.get("code_loc") is not None:
            rec["code_loc"] = s["code_loc"]
        if s.get("runs") is not None:
            rec["runs"] = s["runs"]
        for _ev in ("request", "actions", "apps_accessed", "sources_reviewed"):
            if s.get(_ev) is not None:
                rec[_ev] = s[_ev]
        if s.get("cowork_fit_review") is not None:
            rec["cowork_fit_review"] = s["cowork_fit_review"]
        if note:
            rec["note"] = note
        classified.append(rec)

    payload = copy.deepcopy(d)
    payload["sessions"] = classified
    with open(out, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=1, allow_nan=False)

    print(f"Classified {len(classified)} sessions ({conv} conversational/no-artifact).")
    proc = collections.Counter(r["process"] for r in classified)
    print("Processes:", ", ".join(f"{p} x{n}" for p, n in proc.most_common()))
    print("wrote", out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="working/cowork_raw.json")
    ap.add_argument("--out", default="working/cowork_sessions.json")
    ap.add_argument("--overrides", default=None,
                    help="explicit manual override file; disabled by default (no saved naming memory)")
    a = ap.parse_args()
    main(a.inp, a.out, a.overrides)
